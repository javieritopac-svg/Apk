package com.versang.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (4 or 1024 or 4096 or 512 or 2)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(CarBridge(), "Car")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class CarBridge {
        @JavascriptInterface fun openMaps() { runOnUiThread {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="))
            try { startActivity(intent) } catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))) }
        } }
        @JavascriptInterface fun openBluetooth() { runOnUiThread { safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } }
        @JavascriptInterface fun openSettings() { runOnUiThread { safeStart(Intent(Settings.ACTION_SETTINGS)) } }
        @JavascriptInterface fun openPhone() { runOnUiThread { safeStart(Intent(Intent.ACTION_DIAL)) } }
        @JavascriptInterface fun openMusic() { runOnUiThread {
            val i = Intent("android.intent.action.MUSIC_PLAYER")
            try { startActivity(i) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Abre tu reproductor desde Aplicaciones", Toast.LENGTH_SHORT).show() }
        } }
        @JavascriptInterface fun openRadio() { runOnUiThread {
            val candidates = listOf("com.tw.radio", "com.android.fmradio", "com.microntek.radio", "com.syu.radio", "com.ts.main")
            var opened = false
            for (pkg in candidates) {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) { startActivity(launch); opened = true; break }
            }
            if (!opened) Toast.makeText(this@MainActivity, "La app de radio de fábrica no se detectó. Se configura según la marca del estéreo.", Toast.LENGTH_LONG).show()
        } }
        @JavascriptInterface fun showApps() { runOnUiThread {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
            AlertDialog.Builder(this@MainActivity).setTitle("Aplicaciones")
                .setItems(labels) { _, which ->
                    val launch = pm.getLaunchIntentForPackage(apps[which].activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }.setNegativeButton("Cerrar", null).show()
        } }
        private fun safeStart(intent: Intent) {
            try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Esta función no está disponible en el estéreo", Toast.LENGTH_SHORT).show() }
        }
    }
}
