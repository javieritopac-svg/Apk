NISSAN VERSA NG LAUNCHER - PROYECTO ANDROID
Versión inicial 1.0 | Android 10 | Pantalla horizontal 1024x600

CONTENIDO
- Proyecto Android Studio en Kotlin.
- Pantalla principal WebView a pantalla completa.
- Accesos: Maps, Bluetooth, Radio FM, Aplicaciones, Teléfono y Configuración.
- Incluye una ilustración vectorial de un sedán blanco estilo Versa.
- Declara la actividad como opción de pantalla de inicio (HOME).

IMPORTANTE
Este paquete es el CÓDIGO FUENTE del launcher, no un APK ya compilado.
En este entorno no está instalado Android SDK/Gradle, por lo que no es posible compilar ni certificar aquí un APK instalable.

CÓMO GENERAR EL APK
1. Instala Android Studio en una computadora.
2. Abre la carpeta VersaNGLauncher (File > Open).
3. Deja que Gradle sincronice y descargue Android Gradle Plugin 8.6.1 y las herramientas SDK necesarias.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en app/build/outputs/apk/debug/app-debug.apk.
6. Copia el APK a una memoria USB o al estéreo e instálalo. Después pulsa Inicio y elige Versa NG Launcher como pantalla de inicio.

LIMITACIONES DE ESTA VERSIÓN
- La apertura de Radio FM intenta reconocer algunos paquetes comunes; las radios genéricas usan aplicaciones de fábrica distintas. Si no abre la radio, se necesita el nombre de paquete de la app Radio instalada.
- El reproductor de música intenta abrir el reproductor del equipo; los controles de pista dependen de la app instalada.
- El clima no está conectado a un proveedor meteorológico todavía.
- El acceso a Maps requiere que Google Maps u otra app de navegación esté instalada.
- La pantalla de aplicaciones muestra las apps que Android permite consultar.

Para integrar la radio FM y el reproductor originales, comparte una foto de la pantalla Aplicaciones donde se vea el icono/nombre de Radio, o el modelo de placa/CPU del estéreo (por ejemplo UIS7862, TS10, FYT, MTK).
